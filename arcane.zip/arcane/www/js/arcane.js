function reLoad(xvar) {

	setTimeout(function(){location.reload();}, xvar);
}

function movePlayer(e) {

	var xPos = e.clientX;
	var yPos = e.clientY;

	document.getElementById('player').style.animation = "fadeOut 600ms 1";
	document.getElementById('player').style.top = yPos - 32 + "px";
	document.getElementById('player').style.left = xPos - 32 + "px";
	document.getElementById('player').style.animation = "fadeIn 600ms 1";
	setTimeout(reset_player_animation, 300);
}

function reset_player_animation() {

	var el = document.getElementById('player');
	el.style.animation = 'none';
	el.offsetHeight; /* trigger reflow */
	el.style.animation = null; 
}

document.addEventListener('click', movePlayer);