<?php
	$xtitle = 'ARCANE ENGINE - APP PROJECT';
?>
<html>
<head>
<title>
<?php echo $xtitle; ?>
</title>
<link type="image/ico" rel="icon" href="img/favicon.ico">
<link type="text/css" rel="stylesheet" href="css/arcane.css">
<script type="text/javascript" src="js/arcane.js"></script>
</head>
<body onload="reLoad(15000);">

<div id="player"><font class="labelText">64x64</font></div>

</body>
</html>
